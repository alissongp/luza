

import models.Cliente;
import models.Funcionario;
import telas.CadatroCliente;

import java.util.Scanner;

/**
 * Sistema de vendas.
 * Crie um programa de vendas que deve ter interação apenas via console, a interface é com você, seja criativo.
 * O sistema deve ser simples, onde o usuário possa cadastrar, excluir e alterar( em memória apenas) clientes,
 * funcionários e produtos, e também seja possível realizar as mesmas operações com as vendas.
 * Para criar este programa, escolha a linguagem que achar melhor, porém, deve aplicar os conceitos de
 * orientação a objeto que estudamos em sala.
 */

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CadatroCliente cadatroCliente = new CadatroCliente();
        cadatroCliente.cadastrarCliente();
        sc.close();
    }
}
